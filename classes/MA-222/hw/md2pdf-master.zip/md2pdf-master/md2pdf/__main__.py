
if __name__ == "__main__":
    from md2pdf.cli import cli, CLI_NAME
    cli(prog_name=CLI_NAME)
