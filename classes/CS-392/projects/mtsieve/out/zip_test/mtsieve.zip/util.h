/*
Name: Ben Lirio
Pledge: I pledge my honor that I have abided by the Stevens Honor System
Date: 4/23/21
*/
#ifndef UTIL
#define UTIL
void* must_malloc(size_t size);
void* must_calloc(size_t nmemb, size_t size);
#endif
