/*******************************************************************************
 * Name        : perm.h
 * Author      : Ben Lirio
 * Date        : 03/16/21
 * Description : Parse function header
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#ifndef PERM_H
#define PERM_H
int parse_perm_str(const char*);
#endif /* PERM_H */
